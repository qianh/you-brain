import{Wt as e,t}from"./runtime-DGxAt5gI.js";var n=e(t);export{n as t};
//# sourceMappingURL=catalog-Nmkx7d4B.js.map