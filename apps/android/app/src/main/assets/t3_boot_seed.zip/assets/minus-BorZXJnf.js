import{o as e}from"./search-CTfj9FjD.js";var t=e(`minus`,[[`path`,{d:`M5 12h14`,key:`1ays0h`}]]);export{t};
//# sourceMappingURL=minus-BorZXJnf.js.map