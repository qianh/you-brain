import{o as e}from"./search-CTfj9FjD.js";var t=e(`terminal`,[[`path`,{d:`M12 19h8`,key:`baeox8`}],[`path`,{d:`m4 17 6-6-6-6`,key:`1yngyt`}]]);export{t};
//# sourceMappingURL=terminal-CE8KAyjQ.js.map