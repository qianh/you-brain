import{o as e}from"./search-CTfj9FjD.js";var t=e(`chevron-left`,[[`path`,{d:`m15 18-6-6 6-6`,key:`1wnfg3`}]]);export{t};
//# sourceMappingURL=chevron-left-Ev3ST9mD.js.map