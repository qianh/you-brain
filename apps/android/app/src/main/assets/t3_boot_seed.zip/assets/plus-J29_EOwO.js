import{o as e}from"./search-CTfj9FjD.js";var t=e(`plus`,[[`path`,{d:`M5 12h14`,key:`1ays0h`}],[`path`,{d:`M12 5v14`,key:`s699le`}]]);export{t};
//# sourceMappingURL=plus-J29_EOwO.js.map