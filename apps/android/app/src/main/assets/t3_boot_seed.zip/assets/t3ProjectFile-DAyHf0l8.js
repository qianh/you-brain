import{Ch as e,UT as t,gS as n,xn as r}from"./utils-fcYT6KYI.js";var i=r(e),a=n(i);function o(e){let n=a(e);return t(n)?n.value:null}export{o as t};
//# sourceMappingURL=t3ProjectFile-DAyHf0l8.js.map