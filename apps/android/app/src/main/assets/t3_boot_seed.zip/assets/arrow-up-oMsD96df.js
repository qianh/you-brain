import{o as e}from"./search-CTfj9FjD.js";var t=e(`arrow-up`,[[`path`,{d:`m5 12 7-7 7 7`,key:`hav0vg`}],[`path`,{d:`M12 19V5`,key:`x0mq9r`}]]);export{t};
//# sourceMappingURL=arrow-up-oMsD96df.js.map